package generics;

public class Test<G,T> {
    G var;
    T var2;
    public void setData(G var, T var2){
        this.var = var;
        this.var2 = var2;
    }
    
    public G getData1(){
        return var;
    }
    public T getData2(){
        return var2;
    }
    
    public void print()
    {
        System.out.println("Class1 Name : "+var.getClass());
        System.out.println("Class2 Name : "+var2.getClass());
    }
    
    public static void main(String[] args) {
        Test<String,Float> tst1 = new Test<>();
        Test<Integer,Character> tst2 = new Test<>();
        
        tst1.setData("Hello",15.43f);
        System.out.println("Data1 : "+tst1.getData1());
        System.out.println("Data2 : "+tst1.getData2());
        tst1.print();
        
        tst2.setData(1267,'K');
        System.out.println("Data1 : "+tst2.getData1());
        System.out.println("Data2 : "+tst1.getData2());
        tst2.print();
    }
}
