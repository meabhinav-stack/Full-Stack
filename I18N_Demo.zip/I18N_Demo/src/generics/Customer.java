
package generics;

public class Customer<T extends Number> {
    
    public void print(T num){
        System.out.println("Type : "+num.getClass().getName());
        System.out.println("Value: "+num);
    }
   
    public static void main(String[] args) {
       Customer<Integer> ob1 = new Customer<>();
       Customer<Double> ob2 = new Customer<>();
       //Customer<String> ob3 = new Customer<>();
       
       ob1.print(15000);
       ob2.print(15000.0);
      // ob3.print("Hello Students");
    }
}
