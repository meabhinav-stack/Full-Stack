package generics;

public class GenericMethod {
    public<M> void swap(M x, M y){
        M tmp;
        System.out.println("Before Val1 : "+x+"\tVal2 : "+y);
        tmp = x;
        x = y;
        y = tmp;
        System.out.println("After Val1 : "+x+"\tVal2 : "+y);
    }
    
    public static void main(String[] args) {
        GenericMethod gm = new GenericMethod();
        gm.swap(10, 20);
        gm.swap("Hi", "Bye");
        gm.swap('A', 'B');
        gm.swap(10.56, 20.48);
    }
}
