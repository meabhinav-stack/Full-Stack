package i18n_demo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.*;

public class Notepad implements ActionListener{
    JFrame frame;
    JMenuBar mbar;
    JMenu file, edit, lang;
    JMenuItem hi, de, en, zh, ar, fr;
    JTextArea txt;
    
    public void init(){
        frame = new JFrame("Notepad");
        mbar = new JMenuBar();
        txt = new JTextArea();
        
        file = new JMenu("File");
        edit = new JMenu("Edit");
        lang = new JMenu("Language");
        
        hi = new JMenuItem("Hindi");
        de = new JMenuItem("German");
        en = new JMenuItem("English");
        zh = new JMenuItem("Chinese");
        ar = new JMenuItem("Arabic");
        fr = new JMenuItem("French");
        
        mbar.add(file);
        mbar.add(edit);
        mbar.add(lang);
        
        lang.add(hi);
        lang.add(de);
        lang.add(en);
        lang.add(zh);
        lang.add(ar);
        lang.add(fr);
        
        hi.addActionListener(this);
        de.addActionListener(this);
        en.addActionListener(this);
        zh.addActionListener(this);
        ar.addActionListener(this);
        fr.addActionListener(this);
        
        frame.add(txt);
        frame.setSize(400, 250);
        frame.setJMenuBar(mbar);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        String res = null;
        Locale loc = null;
        switch(ae.getActionCommand()){
            case "Hindi":
                res = "resources/hi_ResourceBundle";
                loc = new Locale("hi","IN");
                break;
            case "German":
                res = "resources/de_ResourceBundle";
                loc = new Locale("de","DE");
                break;
            case "Chinese":
                res = "resources/zh_ResourceBundle";
                loc = new Locale("zh","ZH");
                break;
            case "French":
                res = "resources/fr_ResourceBundle";
                loc = new Locale("fr","FR");
                break;
            case "English":
                res = "resources/en_ResourceBundle";
                loc = new Locale("en","IN");
                break;
        }
        ResourceBundle rbl = ResourceBundle.getBundle(res, loc);
        file.setText(rbl.getString("file"));
        edit.setText(rbl.getString("edit"));
        frame.setTitle(rbl.getString("title"));
        txt.setText(rbl.getString("niit"));
    }
    
    public static void main(String[] args) {
        Notepad np = new Notepad();
        np.init();
       
    }
}
