
package i18n_demo;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

public class I18N_Demo {
    Locale loc;
    
    public void dateFormat(){
        loc = new Locale("ru", "RU");
        
        DateFormat df = DateFormat.getDateInstance(DateFormat.LONG, loc);
        
        System.out.println("Today is : "+df.format(new Date()));
    }
    
    public void timeFormat(){
        loc = new Locale("hi", "IN");
        
        DateFormat df = DateFormat.getTimeInstance(DateFormat.LONG, loc);
        
        System.out.println("Today is : "+df.format(new Date()));
    }
    
    public void currencyFormat(){
        loc = new Locale("de", "DE");
        
        NumberFormat df = NumberFormat.getCurrencyInstance(loc);
        
        System.out.println("Salary : "+df.format(4587900));
    }
    
    public void textFormat(){
        loc = new Locale("hi", "IN");
        ResourceBundle rbl = ResourceBundle.getBundle("resources/hi_ResourceBundle", loc);
        System.out.println("Welcome in hindi : "+rbl.getString("message"));
    }
    public static void main(String[] args) {
        I18N_Demo idm = new I18N_Demo();
        idm.dateFormat();
        idm.timeFormat();
        
        idm.currencyFormat();
        idm.textFormat();
    }
    
}
